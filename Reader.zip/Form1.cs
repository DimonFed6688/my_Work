﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TreeViewExample
{
    public partial class Form1 : Form
    {
        private string historyFilePath = "history.txt"; // Путь к файлу истории
        private int currentPage = 1;
        string text;
        int pageLength = 1540; // Замените это значение на количество символов на странице      
        readonly string bookName;
        DateTime viewDateTime = DateTime.Now;
        readonly string filePath = Path.Combine(Application.StartupPath);
        private int savedPosition = 0;

        

        public Form1()
        {
            InitializeComponent();
            LoadDirectories(filePath, treeView1.Nodes); // Загрузка диска C: по умолчанию     

        }
        private void LoadDirectories(string filepath, TreeNodeCollection parentNode)
        {
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(filepath);//DirectoryInfo. Этот объект представляет каталог в файловой системе компьютера. 
                TreeNode directoryNode = new TreeNode(directoryInfo.Name);//TreeNode. Этот объект представляет узел в древовидной структуре.
                parentNode.Add(directoryNode);

                foreach (string directory in Directory.GetDirectories(filepath)) 
                {
                    LoadDirectories(directory, directoryNode.Nodes);//Цель этой функции - загрузить каталоги в текущем каталоге
                                                                    //и добавить их в качестве узлов в directoryNode.Nodes коллекцию.
                }

                foreach (string file in Directory.GetFiles(filepath))
                {
                    TreeNode fileNode = new TreeNode(Path.GetFileName(file));
                    fileNode.Tag = file; // Сохранение пути к файлу в метке узла
                    directoryNode.Nodes.Add(fileNode);
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                // Обработка ошибки доступа к каталогам
                richTextBox1.Text = "Ошибка доступа к каталогам: " + ex.Message;
            }
        }
        private void Закрыть_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {
            richTextBox1.Clear();
            if (e.Node != null && e.Node.Tag is string filePath)
            {
                string extension = Path.GetExtension(filePath);
                if (extension == ".txt" || extension == ".fb2" || extension == ".pdf")
                {
                    try
                    {
                        //код загружает содержимое файла, указанного с помощью filePath в XElement переменную,
                        //вызываемую fileContent с помощью XElement.Load() метода.
                        XElement fileContent = XElement.Load(filePath);

                        richTextBox1.Text = fileContent.Value;

                        this.Text = "Просмотр файла: " + filePath;



                    }
                    catch (Exception ex)
                    {
                        richTextBox1.Text = "Ошибка чтения файла: " + ex.Message;
                    }
                }
                else
                {
                    richTextBox1.Text = "Неподдерживаемый тип файла. Поддерживаемые типы: .txt, .fb2, .pdf";
                }
                text = richTextBox1.Text;
                // Отображаем первую страницу
                DisplayPage(currentPage);
            }
        }

        private void DisplayPage(int page)
        {
            try
            {
                // Очищаем richTextBox1 перед выводом страницы
                richTextBox1.Clear();

                int startIndex = page * pageLength; // вычисляет начальный индекс символа для текущей страницы путем
                                                    // умножения номера страницы на количество символов на странице.

                int length = Math.Min(pageLength, text.Length - startIndex); // вычисляет длину текста для текущей страницы.

                richTextBox1.AppendText(text.Substring(startIndex, length)); //добавляет подстроку из оригинального текста в элемент
                                                                             //управления richTextBox1, что и представляет собой текущую страницу.

                // Определение всех страниц в тексте
                int totalPages = (int)Math.Ceiling((double)text.Length / pageLength);

                // Вывод информации через Label1
                label1.Text = $"Всего страниц: {totalPages}, Страница: {page + 1}"; // Отображает общее количество страниц и
                                                                                    // текущую страницу

            }
            catch { richTextBox1.Text = "Ошибка чтения файла: "; }
        }

        private void button1_Click(object sender, EventArgs e) // Переход на предыдущую страницу, если возможно
        {
            if (currentPage > 0)
            {
                currentPage--;
                DisplayPage(currentPage);
            }
        }

        private void button2_Click(object sender, EventArgs e) // Переход на следующую страницу, если возможно
        {
            if ((currentPage + 1) * pageLength < text.Length)
            {
                currentPage++;
                DisplayPage(currentPage);
            }
        }

        private void button3_Click(object sender, EventArgs e)  // Открытие файла истории при клике на кнопку
        {
            AddToHistory(filePath, bookName, viewDateTime, historyFilePath);
            OpenHistoryFile();
        }
        private void AddToHistory(string filePath, string bookName, DateTime viewDateTime, string historyFilePath)
        {
            try
            {
                using (StreamWriter sw = File.AppendText(historyFilePath)) //StreamWriter для добавления строки текста в файл.
                {
                    //sw.WriteLine метод для записи строки текста в файл.
                    sw.WriteLine($"Название файла: {bookName}, Путь к файлу: {filePath}, Дата и время: { viewDateTime}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления файла в историю: " + ex.Message);
            }
        }
        private void OpenHistoryFile()
        {
            try
            {
                //Этот метод считывает содержимоеhistoryText. Путь к файлу указывается переменной historyFilePath.
                string historyText = File.ReadAllText(historyFilePath);
                richTextBox1.Text = ("История просмотров:\n\n" + historyText);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка открытия файла истории: " + ex.Message);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)  // Меняем цвет фона
        {
            richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Regular);
            richTextBox1.ForeColor = Color.Black;
            richTextBox1.BackColor = Color.Moccasin;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e) // Ночной режим и полужирный текст (просто эксперемент)
        {
            richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Bold);
            richTextBox1.ForeColor = Color.White;
            richTextBox1.BackColor = Color.Black;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)  // Стандартный фон и текст
        {
            richTextBox1.Font = new Font(richTextBox1.Font, FontStyle.Regular);
            richTextBox1.ForeColor = Color.Black;
            richTextBox1.BackColor = Color.White;
        }

        private void button4_Click(object sender, EventArgs e) //Ищем нужную страницу.
        {

            if (int.TryParse(textBox1.Text, out int pageNumber)) // Пытаемся преобразовать текст из textBox1 в число
            {

                int totalPages = (int)Math.Ceiling((double)text.Length / pageLength); // Определяем общее количество страниц
                if (pageNumber >= 1 && pageNumber <= totalPages) // Проверяем, что указанный номер страницы находится в допустимом диапазоне
                {

                    int startIndex = (pageNumber - 1) * pageLength; // Находим индекс начала страницы
                    int length = Math.Min(pageLength, textBox1.Text.Length - startIndex); // Находим длину текста для текущей страницы

                    currentPage = Convert.ToInt32(textBox1.Text);
                    DisplayPage(currentPage);

                    label1.Text = $"Всего страниц: {totalPages}, Страница: {pageNumber}"; // Обновляем информацию о странице в label1
                }
                else
                {
                    richTextBox1.Text = "Указанная страница не существует.";
                }
            }
            else
            {
                richTextBox1.Text = "Введите корректный номер страницы.";
            }


        }
        private void button5_Click(object sender, EventArgs e) //Поиск по слову или тексту
        {
            string searchText = textBox2.Text;
            int index = text.IndexOf(searchText, StringComparison.CurrentCultureIgnoreCase); // ищем первое вхождение искомого текста

            if (index != -1)
            {
                int page = index / pageLength; // вычисляем номер страницы, на которой находится искомый текст
                DisplayPage(page); // отображаем найденную страницу
                int start = index - (page * pageLength);// вычисляем смещение от начала страницы до найденного текста
                richTextBox1.Select(start, searchText.Length); // выделяем искомое слово
                richTextBox1.SelectionBackColor = Color.Yellow;// устанавливаем желтый цвет выделенного текста

            }
        }
        private void SaveSelectedText()
        {
            if (richTextBox1.SelectionLength > 0)
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.Filter = "Text Files|*.txt";
                saveFileDialog1.Title = "Save Selected Text";
                saveFileDialog1.ShowDialog();

                if (saveFileDialog1.FileName != "")
                {
                    using (StreamWriter sw = new StreamWriter(saveFileDialog1.OpenFile()))
                    {
                        sw.Write(richTextBox1.SelectedText);
                    }
                }
            }
            else { richTextBox1.Text = "Не выбран текст!!!"; }
        }

        private void button6_Click(object sender, EventArgs e) // Сохранение выделенного текста
        {
            SaveSelectedText();
        }

        private void richTextBox1_MouseDown(object sender, MouseEventArgs e) // Сохранение выделенного текста
        {
            if (e.Button == MouseButtons.Right)
            {
                SaveSelectedText();
            }
        }     

        private void button8_Click(object sender, EventArgs e)  // Восстанавливаем значение savedPosition при нажатии кнопки
        {
           
            if (TreeView.Properties.Settings.Default.SavedPosition != 0)
            {
                savedPosition = TreeView.Properties.Settings.Default.SavedPosition;
                richTextBox1.SelectionStart = savedPosition;
                richTextBox1.ScrollToCaret();

            }
        }         

        private void richTextBox1_MouseDoubleClick_1(object sender, MouseEventArgs e)  // Также можно сохранять значение savedPosition в пользовательские настройки
        {
            savedPosition = richTextBox1.SelectionStart;
            string text = richTextBox1.Text.Substring(0, savedPosition);
            int characterCount = text.Length;
           
            TreeView.Properties.Settings.Default.SavedPosition = savedPosition;
            TreeView.Properties.Settings.Default.Save();
        }

        private void Form1_Load(object sender, EventArgs e)  // Восстанавливаем значение savedPosition при загрузке приложения
        {            
            if (TreeView.Properties.Settings.Default.SavedPosition != 0)
            {
                savedPosition = TreeView.Properties.Settings.Default.SavedPosition;
                richTextBox1.SelectionStart = savedPosition;
                richTextBox1.ScrollToCaret();
            }
        }
    }
}

