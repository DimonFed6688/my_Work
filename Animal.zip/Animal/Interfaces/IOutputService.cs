﻿namespace AnimalHierarchy.Interfaces
{
    public interface IOutputService
    {
        void Write(string message);
    }
}
