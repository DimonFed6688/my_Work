﻿namespace AnimalHierarchy.Interfaces
{
    public interface IAnimal
    {
        void Info();
        void Speak();
    }
}
