﻿using AnimalHierarchy.Interfaces;
using System.IO;

namespace AnimalHierarchy.Services
{
    public class FileOutputService : IOutputService
    {
        private readonly string _filePath;

        public FileOutputService(string filePath)
        {
            _filePath = filePath;
        }

        public void Write(string message)
        {
            using (var writer = new StreamWriter(_filePath, true))
            {
                writer.WriteLine(message);
            }
        }
    }
}
