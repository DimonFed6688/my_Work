﻿using AnimalHierarchy.Interfaces;
using System;

namespace AnimalHierarchy.Services
{
    public class ConsoleOutputService : IOutputService
    {
        public void Write(string message)
        {
            Console.WriteLine(message);
        }
    }
}
