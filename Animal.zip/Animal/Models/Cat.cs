﻿using AnimalHierarchy.Interfaces;

namespace AnimalHierarchy.Models
{
    public class Cat : Animal
    {
        public string Ears { get; set; }
        public int Paws { get; set; }
        public string Tail { get; set; }

        public Cat(IOutputService outputService) : base(outputService)
        {
            Ears = "Pointy";
            Paws = 4;
            Tail = "Long";
        }

        public override void Info()
        {
            _outputService.Write($"Cat Info: Ears - {Ears}, Paws - {Paws}, Tail - {Tail}");
        }

        public override void Speak()
        {
            _outputService.Write("Cat says: Meow!");
        }
    }
}
