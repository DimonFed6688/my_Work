﻿using AnimalHierarchy.Interfaces;

namespace AnimalHierarchy.Models
{
    public abstract class Animal : IAnimal
    {
        protected IOutputService _outputService;

        protected Animal(IOutputService outputService)
        {
            _outputService = outputService;
        }

        public abstract void Info();
        public abstract void Speak();
    }
}
