﻿using AnimalHierarchy.Interfaces;

namespace AnimalHierarchy.Models
{
    public class Bird : Animal
    {
        public string Wings { get; set; }
        public string Tail { get; set; }

        public Bird(IOutputService outputService) : base(outputService)
        {
            Wings = "Wide";
            Tail = "Short";
        }

        public override void Info()
        {
            _outputService.Write($"Bird Info: Wings - {Wings}, Tail - {Tail}");
        }

        public override void Speak()
        {
            _outputService.Write("Bird says: Tweet!");
        }
    }
}
