using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using AnimalHierarchy.Interfaces;
using AnimalHierarchy.Services;
using AnimalHierarchy.Models;

var builder = WebApplication.CreateBuilder(args);

// ����������� ��������
builder.Services.AddTransient<IOutputService, ConsoleOutputService>(); // ��� FileOutputService � ��������� ����
builder.Services.AddTransient<Cat>();
builder.Services.AddTransient<Bird>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseRouting();

app.UseEndpoints(endpoints =>
{
    endpoints.MapGet("/", async context =>
    {
        var cat = context.RequestServices.GetService<Cat>();
        var bird = context.RequestServices.GetService<Bird>();

        cat.Info();
        cat.Speak();

        bird.Info();
        bird.Speak();

        await context.Response.WriteAsync("Check the console or file output for animal info and sounds.");
    });
});

app.Run();
